# Multimodal Pain Risk Detection System (Bone + Muscle + Skin)

ESP32 wearable + Machine Learning + emergency alert.
Three separate models (one per body system) are combined by **late fusion** into one pain-risk score.

| Module | Dataset (real)                              | Input                        | Output            |
|--------|---------------------------------------------|------------------------------|-------------------|
| Bone   | UCI Vertebral Column (id 212)               | 6 spine/pelvis angles        | Normal / Abnormal |
| Muscle | UCI EMG Dataset in Lower Limb (id 278)      | EMG signal (windowed)        | Healthy / Abnormal|
| Skin   | PhysioPain (Mendeley) or PainMonit          | EDA + skin temperature       | Pain / No pain    |

Fusion: weighted average of the 3 probabilities (weights = F1 score of each model)
-> score 0-1 -> LOW (<0.4), MEDIUM (0.4-0.7), HIGH (>=0.7) -> HIGH sends an alert (console + optional Firebase).
If a sensor is missing, the remaining modules are used.

## Run (3 commands)
```
pip install -r requirements.txt
python src/train_all.py        # trains 3 models, saves to models/
python src/demo.py             # prints fused prediction + alert
python src/app.py              # starts API on port 5000 (for ESP32 / app)
```
`data/` currently contains **synthetic demo data** (made by `src/make_demo_data.py`) so everything runs
immediately. Replace with real data before you report results.

## Using the real datasets
1. **bone.csv**: download Vertebral Column, save as `data/bone.csv` (needs a `class` column: Normal/Abnormal).
2. **muscle.csv**: put UCI EMG files in `data/raw_emg/healthy/` and `data/raw_emg/knee/`, then
   `python src/prepare_real_data.py muscle`. Open the csv and check the columns look right.
3. **skin.csv**: columns `eda,temp,bvp,label,subject` (label 1 = pain, 0 = no pain), built from PhysioPain.
Then run `python src/train_all.py` again.

## API (for ESP32 / mobile app)
POST `/predict` with JSON; every key is optional:
```
{"user":"patient-1",
 "bone":{"pelvic_incidence":60,"pelvic_tilt":18,"lumbar_lordosis_angle":50,"sacral_slope":42,"pelvic_radius":118,"degree_spondylolisthesis":20},
 "emg":[[0.1],[0.3],...],                 // rows of samples, 200 per window
 "skin":{"eda":[...40 values...],"temp":[...40 values...]}}
```
Optional Firebase alerts: `export FIREBASE_DB_URL=https://<project>-default-rtdb.firebaseio.com`

## Hardware (esp32/esp32_pain_sensor.ino)
ESP32 + GSR sensor (GPIO34) + LM35 temperature (GPIO35) + EMG sensor e.g. MyoWare (GPIO32).
Edit Wi-Fi name, password and the PC IP in the sketch.
Bone inputs (spine angles) cannot come from these sensors; enter them from the app, or add an MPU6050 later.

## Limitations (write these in your report)
- Datasets come from different people, so fusion is late fusion of independent models, not one joint model.
- Bone and muscle labels are "abnormal condition", not directly "pain"; only the skin dataset has pain labels.
- Not a medical diagnosis device; it gives a risk estimate only.
- Report subject-wise test results (the code already splits by subject for muscle and skin).

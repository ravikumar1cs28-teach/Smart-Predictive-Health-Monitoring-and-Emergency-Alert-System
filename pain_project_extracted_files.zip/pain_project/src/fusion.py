"""Late fusion: combine bone, muscle and skin pain probabilities into one risk score."""

LEVELS = [(0.70, "HIGH"), (0.40, "MEDIUM"), (0.0, "LOW")]


def risk_level(score):
    for thr, name in LEVELS:
        if score >= thr:
            return name


def fuse(probs, weights):
    """probs: dict modality -> P(pain/abnormal) (missing modalities may be absent/None).
    weights: dict modality -> weight (e.g. validation F1)."""
    avail = {k: v for k, v in probs.items() if v is not None and k in weights}
    if not avail:
        raise ValueError("No modality available")
    tot = sum(weights[k] for k in avail)
    score = sum(weights[k] * v for k, v in avail.items()) / tot
    # safety rule: any single very confident modality raises the alarm
    if max(avail.values()) >= 0.95:
        score = max(score, 0.70)
    return {"score": round(float(score), 3), "level": risk_level(score),
            "used": sorted(avail), "per_modality": {k: round(float(v), 3) for k, v in avail.items()}}

"""Command-line demo: takes real rows from the data files and prints fused prediction."""
import os, sys, pandas as pd, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from predictor import PainPredictor
from features import clean_bone_df, BONE_COLS
from alert import send_alert

p = PainPredictor()
bone = clean_bone_df(pd.read_csv("data/bone.csv"))
muscle = pd.read_csv("data/muscle.csv")
skin = pd.read_csv("data/skin.csv")

for title, lab in (("NO PAIN sample", 0), ("PAIN sample", 1)):
    b = bone[bone["class"].str.lower() == ("normal" if lab == 0 else "abnormal")].iloc[5]
    m = muscle[muscle.label == lab].iloc[:200][[c for c in muscle.columns if c.startswith("ch")]].values
    s = skin[skin.label == lab].iloc[:40]
    res = p.predict(bone={c: b[c] for c in BONE_COLS}, emg=m.tolist(),
                    skin={"eda": s.eda.tolist(), "temp": s.temp.tolist(), "bvp": s.bvp.tolist()})
    print(f"\n{title}: {res}")
    if res["level"] == "HIGH":
        send_alert(res)

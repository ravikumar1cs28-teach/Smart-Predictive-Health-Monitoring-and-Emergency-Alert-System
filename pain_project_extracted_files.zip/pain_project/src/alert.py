"""Emergency alert. Prints to console and (optionally) pushes to Firebase Realtime Database.
Set env var FIREBASE_DB_URL, e.g. https://your-project-default-rtdb.firebaseio.com"""
import os, time, json
import requests


def send_alert(result, user="patient-1"):
    msg = {"user": user, "level": result["level"], "score": result["score"],
           "details": result["per_modality"], "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    print("\n*** EMERGENCY ALERT ***", json.dumps(msg))
    url = os.getenv("FIREBASE_DB_URL")
    if url:
        try:
            requests.post(url.rstrip("/") + "/alerts.json", json=msg, timeout=5)
        except Exception as e:                     # never crash the monitoring loop
            print("Firebase push failed:", e)
    return msg

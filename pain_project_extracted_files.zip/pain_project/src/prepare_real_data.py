"""Helpers to convert the REAL downloaded datasets into the csv layout used by this project.
Run the function you need, e.g.:  python src/prepare_real_data.py muscle
Check the first rows of the output csv - file layouts can differ between dataset versions.

bone   : download Vertebral Column (UCI id 212, or Kaggle 'vertebral_column_2C.csv')
         and save it as data/bone.csv   (needs a 'class' column: Normal / Abnormal).
muscle : UCI 'EMG dataset in Lower Limb' text files. Put healthy files in data/raw_emg/healthy/
         and knee-abnormal files in data/raw_emg/knee/ -> creates data/muscle.csv
skin   : PhysioPain / PainMonit. Build a csv with columns  eda,temp,bvp,label,subject
         (label 1 = pain, 0 = no pain) -> save as data/skin.csv
"""
import sys, glob, os
import pandas as pd


def prepare_muscle(root="data/raw_emg"):
    frames = []
    for lab, folder in ((0, "healthy"), (1, "knee")):
        for i, f in enumerate(sorted(glob.glob(f"{root}/{folder}/*"))):
            df = pd.read_csv(f, sep=r"\s+", header=None, engine="python", on_bad_lines="skip")
            df = df.apply(pd.to_numeric, errors="coerce").dropna()
            df = df.iloc[:, :4]                       # 4 EMG channels (5th column = goniometer)
            df.columns = ["ch1", "ch2", "ch3", "ch4"]
            df["label"], df["subject"] = lab, f"{folder}_{i}"
            frames.append(df)
    if not frames:
        sys.exit(f"No files found in {root}/healthy and {root}/knee")
    pd.concat(frames).to_csv("data/muscle.csv", index=False)
    print("saved data/muscle.csv")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "muscle":
        prepare_muscle()
    else:
        print(__doc__)

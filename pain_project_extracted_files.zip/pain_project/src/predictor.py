"""Load trained models and give a fused pain-risk prediction."""
import json, os, joblib, numpy as np
from features import BONE_COLS, emg_features, skin_features
from fusion import fuse

BASE = os.path.join(os.path.dirname(__file__), "..", "models")


class PainPredictor:
    def __init__(self):
        cfg = json.load(open(os.path.join(BASE, "fusion.json")))
        self.weights = cfg["weights"]
        self.models = {k: joblib.load(os.path.join(BASE, f"{k}.joblib"))
                       for k in self.weights if os.path.exists(os.path.join(BASE, f"{k}.joblib"))}

    def predict(self, bone=None, emg=None, skin=None):
        """bone: dict of 6 angles | emg: list of [ch1..chN] rows | skin: dict(eda=[..], temp=[..], bvp=[..])"""
        probs = {}
        if bone is not None and "bone" in self.models:
            x = np.array([[float(bone[c]) for c in BONE_COLS]])
            probs["bone"] = self.models["bone"].predict_proba(x)[0][1]
        if emg is not None and "muscle" in self.models:
            arr = np.array(emg, dtype=float)
            n_ch = self.models["muscle"].n_features_in_ // 5
            if arr.shape[1] < n_ch:               # e.g. ESP32 with 1 EMG sensor: repeat the channel
                arr = np.repeat(arr[:, :1], n_ch, axis=1)
            x = emg_features(arr).reshape(1, -1)
            probs["muscle"] = self.models["muscle"].predict_proba(x)[0][1]
        if skin is not None and "skin" in self.models:
            x = skin_features(skin["eda"], skin["temp"], skin.get("bvp")).reshape(1, -1)
            probs["skin"] = self.models["skin"].predict_proba(x)[0][1]
        return fuse(probs, self.weights)

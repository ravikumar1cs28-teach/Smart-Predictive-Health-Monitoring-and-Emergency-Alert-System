"""Train bone, muscle and skin models + save fusion weights.
Usage: python src/train_all.py"""
import os, sys, json, joblib, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.metrics import accuracy_score, f1_score, classification_report
from features import bone_xy, muscle_xy, skin_xy

os.makedirs("models", exist_ok=True)


def fit_eval(name, X, y, groups=None):
    if groups is not None:   # split by subject so the same person is never in train and test
        tr, te = next(GroupShuffleSplit(1, test_size=0.25, random_state=42).split(X, y, groups))
    else:
        tr, te = train_test_split(np.arange(len(y)), test_size=0.25, random_state=42, stratify=y)
    clf = RandomForestClassifier(n_estimators=200, class_weight="balanced", random_state=42)
    clf.fit(X[tr], y[tr])
    pred = clf.predict(X[te])
    acc, f1 = accuracy_score(y[te], pred), f1_score(y[te], pred)
    print(f"\n=== {name.upper()} ===  accuracy={acc:.3f}  F1={f1:.3f}  (samples={len(y)})")
    print(classification_report(y[te], pred, zero_division=0))
    joblib.dump(clf, f"models/{name}.joblib")
    return {"accuracy": round(acc, 3), "f1": round(f1, 3)}


metrics = {}
if os.path.exists("data/bone.csv"):
    X, y = bone_xy(pd.read_csv("data/bone.csv"))
    metrics["bone"] = fit_eval("bone", X, y)
if os.path.exists("data/muscle.csv"):
    X, y, g = muscle_xy(pd.read_csv("data/muscle.csv"))
    metrics["muscle"] = fit_eval("muscle", X, y, g)
if os.path.exists("data/skin.csv"):
    X, y, g = skin_xy(pd.read_csv("data/skin.csv"))
    metrics["skin"] = fit_eval("skin", X, y, g)

if not metrics:
    sys.exit("No data found in data/. Run: python src/make_demo_data.py  (or add real csv files)")

weights = {k: max(v["f1"], 0.05) for k, v in metrics.items()}
json.dump({"metrics": metrics, "weights": weights}, open("models/fusion.json", "w"), indent=2)
print("\nSaved models + fusion weights:", weights)

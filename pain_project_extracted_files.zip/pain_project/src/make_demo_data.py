"""Creates SMALL SYNTHETIC csv files with the same layout as the real datasets,
so the whole pipeline can be tested before you download the real data.
Real data: see README.md."""
import numpy as np, pandas as pd, os
rng = np.random.default_rng(0)
os.makedirs("data", exist_ok=True)

# bone: 310 rows like UCI Vertebral Column (2 classes)
n_norm, n_ab = 100, 210
def block(n, mu, sd):
    return rng.normal(mu, sd, size=(n, 6))
nor = block(n_norm, [51, 12, 44, 39, 124, 2.5], [12, 7, 12, 9, 9, 6])
ab = block(n_ab, [64, 19, 55, 45, 115, 25], [17, 10, 17, 11, 14, 30])
cols = ["pelvic_incidence", "pelvic_tilt", "lumbar_lordosis_angle", "sacral_slope",
        "pelvic_radius", "degree_spondylolisthesis"]
bone = pd.DataFrame(np.vstack([nor, ab]), columns=cols)
bone["class"] = ["Normal"] * n_norm + ["Abnormal"] * n_ab
bone.to_csv("data/bone.csv", index=False)

# muscle: raw EMG, 4 channels, 1000 Hz, 22 subjects (11 healthy / 11 abnormal)
rows = []
for s in range(22):
    lab = int(s >= 11)
    amp = 1.0 if lab == 0 else 0.6                     # weaker, noisier muscle activity in abnormal
    noise = 0.15 if lab == 0 else 0.30
    t = np.arange(4000)
    env = 0.5 + 0.5 * np.sin(2 * np.pi * t / 1000 + rng.uniform(0, 3))
    sig = np.stack([amp * env * rng.normal(0, 1, len(t)) + rng.normal(0, noise, len(t))
                    for _ in range(4)], axis=1)
    d = pd.DataFrame(sig, columns=["ch1", "ch2", "ch3", "ch4"])
    d["label"], d["subject"] = lab, s
    rows.append(d)
pd.concat(rows).to_csv("data/muscle.csv", index=False)

# skin: EDA (4 Hz), temp, bvp ; 40 subjects
rows = []
for s in range(40):
    for lab in (0, 1):
        n = 400
        eda = rng.normal(2.0 + 1.2 * lab, 0.35, n) + np.cumsum(rng.normal(0.004 * lab, 0.01, n))
        temp = rng.normal(33.5 - 0.7 * lab, 0.25, n)
        bvp = rng.normal(0, 1 + 0.4 * lab, n)
        d = pd.DataFrame({"eda": eda, "temp": temp, "bvp": bvp})
        d["label"], d["subject"] = lab, s
        rows.append(d)
pd.concat(rows).to_csv("data/skin.csv", index=False)
print("demo data written to data/")

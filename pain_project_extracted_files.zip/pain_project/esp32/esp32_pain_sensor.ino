// ESP32 -> collects skin (GSR/EDA + temperature) and muscle (EMG) data, sends to Flask API.
// Sensors (low cost): GSR sensor -> GPIO34, LM35 temperature -> GPIO35, MyoWare/EMG -> GPIO32
// Change WIFI_SSID, WIFI_PASS and SERVER_URL (PC running src/app.py, same Wi-Fi).
#include <WiFi.h>
#include <HTTPClient.h>

const char* WIFI_SSID  = "YOUR_WIFI";
const char* WIFI_PASS  = "YOUR_PASSWORD";
const char* SERVER_URL = "http://192.168.1.10:5000/predict";

const int PIN_GSR = 34, PIN_TEMP = 35, PIN_EMG = 32;
const int SKIN_N = 40;      // 40 samples @ 4 Hz  = 10 s
const int EMG_N  = 200;     // 200 samples @ 1 kHz = 0.2 s
float eda[SKIN_N], temp[SKIN_N];
int   emg[EMG_N];

void setup() {
  Serial.begin(115200);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nWiFi connected");
}

void loop() {
  // 1) skin window (10 s)
  for (int i = 0; i < SKIN_N; i++) {
    eda[i]  = analogRead(PIN_GSR) * (3.3 / 4095.0);            // volts (proxy for conductance)
    temp[i] = analogRead(PIN_TEMP) * (3.3 / 4095.0) * 100.0;   // LM35: 10 mV per deg C
    delay(250);
  }
  // 2) muscle window (0.2 s)
  for (int i = 0; i < EMG_N; i++) { emg[i] = analogRead(PIN_EMG) - 2048; delayMicroseconds(1000); }

  String body = "{\"user\":\"patient-1\",\"skin\":{\"eda\":[";
  for (int i = 0; i < SKIN_N; i++) { body += String(eda[i], 3);  if (i < SKIN_N - 1) body += ","; }
  body += "],\"temp\":[";
  for (int i = 0; i < SKIN_N; i++) { body += String(temp[i], 2); if (i < SKIN_N - 1) body += ","; }
  body += "]},\"emg\":[";
  for (int i = 0; i < EMG_N; i++) { body += "[" + String(emg[i]) + "]"; if (i < EMG_N - 1) body += ","; }
  body += "]}";

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  Serial.printf("HTTP %d -> %s\n", code, http.getString().c_str());
  http.end();
}
